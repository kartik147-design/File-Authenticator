package views;

import dao.DataDAO;
import model.Data;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class UserView {
    private String email;

    UserView(String email) {
        this.email = email;
    }

    public void home() {
        do {
            System.out.println("Welcome " + this.email);
            System.out.println("Press 1 to show hidden files");
            System.out.println("Press 2 to hide a new file");
            System.out.println("Press 3 to unhide a file");
            System.out.println("Press 4 to Synchronize Files");
            System.out.println("Press 5 to covert into a .zip file");
            System.out.println("Press 0 to exit");

            Scanner sc = new Scanner(System.in);
            int ch = Integer.parseInt(sc.nextLine());
            switch (ch) {
                case 1 -> {
                    try {
                        List<Data> files = DataDAO.getAllFiles(this.email);
                        System.out.println("ID - File Name");
                        for (Data file : files) {
                            System.out.println(file.getId() + " - " + file.getFileName());
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
                case 2 -> {
                    System.out.println("Enter the file path");
                    String path = sc.nextLine();
                    File f = new File(path);
                    Data file = new Data(0, f.getName(), path, this.email);
                    try {
                        DataDAO.hideFile(file);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                case 3 -> {
                    List<Data> files = null;
                    try {
                        files = DataDAO.getAllFiles(this.email);

                        System.out.println("ID - File Name");
                        for (Data file : files) {
                            System.out.println(file.getId() + " - " + file.getFileName());
                        }
                        System.out.println("Enter the id of file to unhide");
                        int id = Integer.parseInt(sc.nextLine());
                        boolean isValidID = false;
                        for (Data file : files) {
                            if (file.getId() == id) {
                                isValidID = true;
                                break;
                            }
                        }
                        if (isValidID) {
                            DataDAO.unhide(id);
                        } else {
                            System.out.println("Wrong ID");
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                case 4 -> {
                    sc = new Scanner(System.in);

                    System.out.println("Enter Directory Path : ");  // taking input of main Directory that have multiple files
                    String dirName = sc.nextLine();

                    File file = new File(dirName);  // Creating object of directory


                    // creating file object of Separator files

                    File pdf = new File(dirName + "\\PDF");
                    File img = new File(dirName + "\\IMAGE");
                    File docx = new File(dirName + "\\DOCUMENT");
                    File txt = new File(dirName + "\\TEXT");
                    File vid = new File(dirName + "\\VIDEO");
                    File aud = new File(dirName+ "\\AUDIO");

                    File[] allfiles = file.listFiles();     // file array of all files present in the directory entered by user

                    for (int i = 0; i < allfiles.length; i++) {

                        String filename = "";   // store name of file
                        String[] extension;     // It store splited file name and extension by "." eg: - fileName.pdf --> ["fileName","pdf"]

                        if (allfiles[i].isFile()) {     // It check is this file is file or directory, if file then execute the block of code

                            filename = allfiles[i].getName();       // extracting file name from absolute path of file
                            extension = filename.split("\\.");      // split file name and extension

                            switch (extension[extension.length - 1]) {      // ["fileName","pdf"] --> get n-1 (extension) of file from this array

                                case "pdf":     // checking if extension if pdf then this block of code executed
                                    File moveto;    // file type variable that store location where file will move
                                    Boolean done;   // store acknowledgement of file move or not
                                    if (!pdf.exists()) {    // firstly this line check if directory not exist then it create directory
                                        if (pdf.mkdir()) {
                                            System.out.println("PDF DONE");  // if directory create the print this line for acknowledgement message.
                                        }
                                    }
                                    moveto = new File(pdf + "\\" + filename);   // this create a file location object where file will move
                                    allfiles[i].renameTo(moveto);    // this line move file from source (allfiles[i]) to destination (moveto).
                                    break;

                                case "docx":
                                    if (!docx.exists()) {
                                        if (docx.mkdir()) {
                                            System.out.println("DOCX DONE");
                                        }
                                    }
                                    moveto = new File(docx + "\\" + filename);
                                    allfiles[i].renameTo(moveto);
                                    break;
                                case "jpg":
                                    if (!img.exists()) {
                                        if (img.mkdir()) {
                                            System.out.println("IMG DONE");
                                        }
                                    }
                                    moveto = new File(img + "\\" + filename);
                                    allfiles[i].renameTo(moveto);
                                    break;
                                case "txt":
                                    if (!txt.exists()) {
                                        if (txt.mkdir()) {
                                            System.out.println("TXT DONE");
                                        }
                                    }
                                    moveto = new File(txt + "\\" + filename);
                                    allfiles[i].renameTo(moveto);
                                    break;
                                case ("mp4"):
                                    if (!vid.exists()) {
                                        if (vid.mkdir()) {
                                            System.out.println("VIDEO DONE");
                                        }
                                    }
                                    moveto = new File(vid + "\\" + filename);
                                    allfiles[i].renameTo(moveto);
                                    break;
                                case ("mp3"):
                                    if (!aud.exists()) {
                                        if (aud.mkdir()) {
                                            System.out.println("AUDIO DONE");
                                        }
                                    }
                                    moveto = new File(aud + "\\" + filename);
                                    allfiles[i].renameTo(moveto);
                                    break;
                            }
                        }
                    }
                }
                case 5 -> {
                    Scanner scanner = new Scanner(System.in);

                    // Taking user input for the source folder
                    System.out.print("Enter the path to the source folder: ");
                    String sourceFolder = scanner.nextLine();

                    Path sourceFolderPath = Paths.get(sourceFolder);

                    if (!Files.isDirectory(sourceFolderPath)) {
                        System.out.println("The specified path is not a directory.");
                        return;
                    }

                    // Create the destination zip file path on the desktop
                    String userHome = System.getProperty("user.home");
                    Path desktopPath = Paths.get(userHome, "Desktop");
                    String zipFileName = sourceFolderPath.getFileName().toString() + ".zip";
                    Path zipPath = desktopPath.resolve(zipFileName);

                    // Buffer size for reading files
                    final int BUFFER_SIZE = 1024;
                    byte[] buffer = new byte[BUFFER_SIZE];

                    // Zip the folder
                    try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipPath.toFile()));
                         Stream<Path> paths = Files.walk(sourceFolderPath)) {
                        paths.filter(path -> !Files.isDirectory(path))
                                .forEach(path -> {
                                    ZipEntry zipEntry = new ZipEntry(sourceFolderPath.relativize(path).toString());
                                    try {
                                        zos.putNextEntry(zipEntry);
                                        Files.copy(path, zos);
                                        zos.closeEntry();
                                    } catch (IOException e) {
                                        System.err.println(e);
                                    }
                                });
                        System.out.println("Folder successfully zipped to " + zipPath);
                    } catch (IOException e) {
                        e.printStackTrace();
                        return;
                    }

                    // Delete the original folder
                    try (Stream<Path> pathsToDelete = Files.walk(sourceFolderPath)) {
                        pathsToDelete.sorted(Comparator.reverseOrder())
                                .map(Path::toFile)
                                .forEach(File::delete);
                        System.out.println("Original folder successfully deleted.");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                case 0 -> {
                    System.exit(0);
                }
            }
        } while (true);
    }
}